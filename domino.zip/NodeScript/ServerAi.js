module.exports.ServerAi = class {
    constructor() {
        this.user = 'AI'
    }
    getUser() { return this.user; }
}